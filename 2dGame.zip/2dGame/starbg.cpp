#include "starbg.h"

StarBG::StarBG()
{

}
