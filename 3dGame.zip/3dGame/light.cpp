# include "light.h"

Light::Light()
{

}
