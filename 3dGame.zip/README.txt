Controles:

Setas: movimenta��o
Barra de espa�o: atira
Enter: reinicia o jogo

Como funciona:

O objetivo � conseguir o maior score poss�vel. A cada segundo voc� ganha 1 ponto de score,
e a cada nave abatida voc� ganha 10 pontos.

Se uma nave encostar em voc�, voc� perde.